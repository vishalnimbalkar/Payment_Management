package com.PaymentManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.PaymentManagement.entity.Account;
import com.PaymentManagement.entity.User;
import com.PaymentManagement.entity.UserAccount;
import com.PaymentManagement.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserService userService;
	
	//register new User
	@PostMapping("/register")
	public String registerUser(@RequestBody User user) {	
		 userService.registerUser(user);
		 return "Data Inserted succesfully";
	}
	
	//login user
	@GetMapping("/login/{username}/{password}")
	public List<User> logIn(@PathVariable String username,@PathVariable String password) {	
		return userService.logIn(username,password);	
	}
	
	//get All Users From Database
	@GetMapping("/getAll")
	public List<User> getUser() {	
		return userService.getUser();
	}
	
	//get user by name
	@GetMapping("/getByName/{name}")
	public List<User> getByName(@PathVariable String name) {	
		return userService.getByName(name);
	}
	
	//get user by id
	@GetMapping("/getAllAcc/{user_id}")
	public List<UserAccount> getAllAcc(@PathVariable int user_id){
		return userService.getAllAcc(user_id);
	}
	
	//update user
	@PutMapping("/update")
	public String updateUser(@RequestBody User user) {
		return userService.updateUser(user);
	}
	
	//Delete User
	@DeleteMapping("/delete/{id}")
	public String deleteUser(@PathVariable int id) {
		return userService.deleteUser(id);
	}
	
	//forget password
	@PutMapping("/forgetpassword/{user_id}/{oldPass}/{newPass}")
	public String forgetPassword(@PathVariable int user_id, @PathVariable String oldPass,@PathVariable String newPass) {
		return userService.forgetPassword(user_id,oldPass,newPass);
	}
	
}
