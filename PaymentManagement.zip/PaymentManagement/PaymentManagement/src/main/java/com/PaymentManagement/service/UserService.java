package com.PaymentManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PaymentManagement.dao.UserDao;
import com.PaymentManagement.entity.Account;
import com.PaymentManagement.entity.User;
import com.PaymentManagement.entity.UserAccount;

@Service
public class UserService {
	
	@Autowired
	UserDao userDao;

	public List<User> getUser() {
		return userDao.getUser();
	}

	public void registerUser(User user) {
		userDao.registerUser(user);
	}

	public List<User> getByName(String name) {
		return userDao.getByName(name);
	}

	public List<UserAccount> getAllAcc(int user_id) {
		return userDao.getAllAcc(user_id);
	}

	public String updateUser(User user) {
		return userDao.updateUser(user);
	}

	public String deleteUser(int id) {
		return userDao.deleteUser(id);
	}

	public List<User> logIn(String username, String password) {
		return userDao.logIn(username,password);
	}

	public String forgetPassword(int user_id,String oldPass, String newPass) {
		String msg="";
		String msg2="";
		String msg3="";
		User user= userDao.forgetPassword(user_id);
		if(user!=null) {
			String password=user.getPassword();
			
			if(oldPass.equals(password)) {
				user.setPassword(newPass);
				userDao.updateForgetPAssword(user);
				msg3="Password updated success";
			}else {
				msg2="Wrong Old Password";
			}
			
		}else {
			msg="User not Found";
		}
		return msg+msg2+msg3;
	}

}
