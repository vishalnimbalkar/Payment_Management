package com.PaymentManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PaymentManagement.dao.AccountDao;
import com.PaymentManagement.dao.UserAccountDao;
import com.PaymentManagement.entity.Account;
import com.PaymentManagement.entity.UserAccount;

@Service
public class UserAccountService {

	@Autowired
	UserAccountDao userAccountDao;

	@Autowired
	AccountDao accountDao;

	public List<UserAccount> getAllUserAccount() {
		return userAccountDao.getAllUserAccount();
	}

	public String addUserAccount(UserAccount userAccount) {
		String msg = "";
		String msg2 = "";
		String msg3 = "";
		if (userAccount.getAccount().getMno().equals(userAccount.getUser().getMno())) {
			
			List<Account> list = accountDao.getAccount();
			for (Account account : list) {
				
				if (account.getMno().equals(userAccount.getAccount().getMno())) {
					if (account.getUserAccount() != null) {
						msg = "Account Already Linked";
					} else {
						userAccountDao.addUserAccount(userAccount);
						msg = "Account added Successfully";
					}
				} 	
			}
			
		} else {
			msg2="Invalid Mobile Number";
		}
		return msg+msg2;
	}
}
