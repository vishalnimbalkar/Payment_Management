package com.PaymentManagement.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.PaymentManagement.entity.Account;
import com.PaymentManagement.entity.PaymentHistory;
import com.PaymentManagement.entity.User;
import com.PaymentManagement.entity.UserAccount;

@Repository
public class PayDao {

	@Autowired
	SessionFactory sf;
	@Autowired
	PaymentHistory ph;

	public List<Account> payToUserByMobileNo(String mno1, String mno2, double rs) {
		Session s=sf.openSession();
		Criteria cri = s.createCriteria(Account.class);
		cri.add(Restrictions.or(Restrictions.eq("mno", mno1), Restrictions.eq("mno", mno2)));
		List<Account> list = cri.list();
		s.close();
		return list;
	}
	public void paymentViaMobileNo(Account account, Account account2, double rs) {
		
		ph.setSend_id(account.getId());
		ph.setReciveid(account2.getId());
		ph.setRs(rs);
		Date date=new Date(System.currentTimeMillis());
		ph.setDate(date);
		Date time=new Date(System.currentTimeMillis());
		ph.setTime(time);
		ph.setType("MobileNo");
		
		Session s=sf.openSession();
		Transaction tra = s.beginTransaction();
		s.update(account2);
		s.update(account);
		s.save(ph);
		tra.commit();
		s.close();
	}

	
	public List<Account> payToUserByAccNo(String acc1, String acc2, double rs) {
		Session s=sf.openSession();
		Criteria cri = s.createCriteria(Account.class);
		cri.add(Restrictions.or(Restrictions.eq("acc_no", acc1), Restrictions.eq("acc_no", acc2)));
		List<Account> list = cri.list();
		s.close();
		return list;
	}
	public void paymentViaAccNo(Account account, Account account2,double rs) {
		
		ph.setSend_id(account.getId());
		ph.setReciveid(account2.getId());
		ph.setRs(rs);
		Date date=new Date(System.currentTimeMillis());
		ph.setDate(date);
		Date time=new Date(System.currentTimeMillis());
		ph.setTime(time);
		ph.setType("Account");
		
		Session s=sf.openSession();
		Transaction tra = s.beginTransaction();
		s.update(account2);
		s.update(account);
		s.save(ph);
		tra.commit();
		s.close();
	}
	
	public List<PaymentHistory> getTransaction() {
		Session s=sf.openSession();
		Criteria cri=s.createCriteria(PaymentHistory.class);
		List<PaymentHistory> list=cri.list();
		s.close();
		return list;
	}
	
	public List<UserAccount> getBalance(int user_id) {
		Session s=sf.openSession();
		User user=s.get(User.class, user_id);
		Criteria cri=s.createCriteria(UserAccount.class);
		cri.add(Restrictions.eq("user", user));
		List<UserAccount> list=cri.list();
		s.close();
		return list;
	}


	
}
