package com.PaymentManagement.service;

import java.util.List;

import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PaymentManagement.dao.PayDao;
import com.PaymentManagement.entity.Account;
import com.PaymentManagement.entity.PaymentHistory;
import com.PaymentManagement.entity.UserAccount;

@Service
public class PayService {

	@Autowired
	PayDao payDao;
	
	public String payToUserByMobileNo(String mno1, String mno2, double rs) {
		String msg1 = "";
		String msg2 = "";
		String msg = "";
		String msg3 = "";
		if(rs>0) {
		List<Account> list = payDao.payToUserByMobileNo(mno1,mno2,rs);
			for (Account account : list) {
				//check first mobile number
					if (account.getMno().equals(mno1)) {
						double bal = account.getBalance();
						
						//check account balance is available or not
						if (bal >= rs) {
							account.setBalance(bal - rs);
							
							for (Account account2 : list) {
								//check second mobile number
								if (account2.getMno().equals(mno2)) {
									double bal2 = account2.getBalance();
									account2.setBalance(bal2 + rs);
									payDao.paymentViaMobileNo(account,account2,rs);
									msg = "Payment Successfully of "+rs+"Rs";
								}	
							}
							
						} else {
							msg1 = "Insufficient balance "+bal+"Rs";
						}
					}
			}
		}else {
			msg3 = "Enter valid cash amount";
		}
		return msg1+msg+msg3;
	}

	public String payToUserByAccNo(String acc1, String acc2, double rs) {
		String msg1 = "";
		String msg = "";
		String msg3 = "";
		if(rs>0) {
		List<Account> list = payDao.payToUserByAccNo(acc1,acc2,rs);
			for (Account account : list) {
				//check first Account number
					if (account.getAcc_no().equals(acc1)) {
						double bal = account.getBalance();
						
						//check account balance is available or not
						if (bal >= rs) {
							account.setBalance(bal - rs);
							
							for (Account account2 : list) {
								//check second Account number
								if (account2.getAcc_no().equals(acc2)) {
									double bal2 = account2.getBalance();
									account2.setBalance(bal2 + rs);
									payDao.paymentViaAccNo(account,account2,rs);
									msg = "Payment Successfully of "+rs+"Rs";
								}	
							}
							
						} else {
							msg1 = "Insufficient balance "+bal+"Rs";
						}
					}
			}
		}else {
			msg3 = "Enter valid cash amount";
		}
		return msg1+msg+msg3;
	}

	public List<PaymentHistory> getTransaction() {
		return payDao.getTransaction();
	}

	public String getBalance(int user_id) {
		List<UserAccount> list= payDao.getBalance(user_id);
		double balance=0.0;
		String msg="";
		if(list.isEmpty()) {
			msg="Account is not added yet";			
		}else {
			for (UserAccount userAccount : list) {
				balance=userAccount.getAccount().getBalance();
				msg="Available Balance is "+balance+"Rs";
			}
		}
		return msg;
	}

}
