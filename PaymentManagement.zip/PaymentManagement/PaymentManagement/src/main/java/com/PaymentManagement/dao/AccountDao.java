package com.PaymentManagement.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.PaymentManagement.entity.Account;
import com.PaymentManagement.entity.User;
import com.PaymentManagement.entity.UserAccount;

@Repository
public class AccountDao {

	@Autowired
	SessionFactory sf;
	
	public List<Account> getAccount() {
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Account.class);
		List<Account> list=cr.list();
		s.close();
		return list;
	}

	public List<Account> getByAccNo(String accNo) {
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Account.class);
		cr.add(Restrictions.eq("acc_no", accNo));
		List<Account> list=cr.list();
		s.close();
		return list;
	}

	public List<Account> getUserAccount() {
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(UserAccount.class);
		List<Account> list=cr.list();
		s.close();
		return list;
	}

}
