package com.PaymentManagement.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.PaymentManagement.entity.Account;
import com.PaymentManagement.entity.User;
import com.PaymentManagement.entity.UserAccount;

@Repository
public class UserDao {
	
	@Autowired
	SessionFactory sf;

	public List<User> getUser() {
		
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(User.class);
		List<User> list=cr.list();
		s.close();
		return list;
	}

	public void registerUser(User user) {
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
	      s.save(user);
		tr.commit();
		s.close();
	}

	public List<User> getByName(String name) {
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(User.class);
		cr.add(Restrictions.eq("name", name));
		List<User> list=cr.list();
		s.close();
		return list;
	}

	public List<UserAccount> getAllAcc(int user_id) {
		Session s=sf.openSession();
//		Criteria cr=s.createCriteria(User.class);
		User user=s.get(User.class, user_id);

			Criteria cr=s.createCriteria(UserAccount.class);
			cr.add(Restrictions.eq("user_id", user.getId()));
			List<UserAccount> list=cr.list();

		s.close();
		return list;
	}

	public String updateUser(User user) {
		Session s=sf.openSession();
		Transaction tra=s.beginTransaction();
		s.update(user);
		tra.commit();
		s.close();
		return "User Updated Success";
	}

	public String deleteUser(int id) {
		String msg="";
		Session s=sf.openSession();
		Transaction tra=s.beginTransaction();
		User user=s.get(User.class, id);
		if(user!=null) {
			s.delete(user);
			msg="Delete Success";
		}
		else {
			msg="Please enter valid user id";
		}
		tra.commit();
		s.close();
		return msg;
	}

	public List<User> logIn(String username, String password) {
		String msg="";
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(User.class);
		cr.add(Restrictions.and(Restrictions.eq("email", username),Restrictions.eq("password", password)));
		List<User> list=cr.list();
		s.close();
		return list;
	}

	public User forgetPassword(int user_id) {
		Session s=sf.openSession();
		User user=s.get(User.class, user_id);
		s.close();
		return user;
	}

	public void updateForgetPAssword(User user) {
		Session s=sf.openSession();
		Transaction tra=s.beginTransaction();
		s.update(user);
		tra.commit();
		s.close();
	}

}
