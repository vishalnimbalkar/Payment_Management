package com.PaymentManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.PaymentManagement.entity.User;
import com.PaymentManagement.entity.UserAccount;
import com.PaymentManagement.service.UserAccountService;

@RestController
public class UserAccountController {

	@Autowired
	UserAccountService userAccountService;
	
	@GetMapping("/getAllUserAccount")
	public List<UserAccount> getAllUserAccount() {
		return userAccountService.getAllUserAccount();
	}
	
	@PostMapping("/addUserAccount")
	public String addUserAccount(@RequestBody UserAccount userAccount) {	
		 return  userAccountService.addUserAccount(userAccount);	
	}

}
