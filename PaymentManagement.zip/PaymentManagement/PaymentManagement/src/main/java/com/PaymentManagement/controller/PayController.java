package com.PaymentManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PaymentManagement.entity.PaymentHistory;
import com.PaymentManagement.service.PayService;

@RestController
@RequestMapping("/pay/")
public class PayController {

	@Autowired
	PayService payService;
	
	//send mooney by mobile number
	@PutMapping("/mobileNo/{mno1}/{mno2}/{rs}")
	public String payToUserByMobileNo(@PathVariable String mno1,@PathVariable String mno2,@PathVariable double rs) {
		return payService.payToUserByMobileNo(mno1,mno2,rs);
	}
	
	//send mooney by account number
	@PutMapping("/accNo/{acc1}/{acc2}/{rs}")
	public String payToUserByAccNo(@PathVariable String acc1,@PathVariable String acc2,@PathVariable double rs) {
		return payService.payToUserByAccNo(acc1,acc2,rs);
	}
	
	//get Transaction history
	@GetMapping("/transaction")
	public List<PaymentHistory> getTransaction() {
		return payService.getTransaction();
	}
	
	//get Account Balance
		@GetMapping("/balance/{user_id}")
		public String getBalance(@PathVariable int user_id) {
			return payService.getBalance(user_id);
		}
	
}
