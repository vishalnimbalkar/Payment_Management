package com.PaymentManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PaymentManagement.entity.Account;
import com.PaymentManagement.entity.User;
import com.PaymentManagement.entity.UserAccount;
import com.PaymentManagement.service.AccountService;

@RestController
@RequestMapping("/account")
public class AccountController {

	@Autowired
	AccountService accountService;
	
		
	@GetMapping("/getAll")
	public List<Account> getAccount() {	
		return accountService.getAccount();
	}
	
	@GetMapping("/getByAccNo/{accNo}")
	public List<Account> getByName(@PathVariable String accNo) {	
		return accountService.getByAccNo(accNo);
	}

	@GetMapping("/get")
	public List<Account> getUserAccount() {	
		return accountService.getUserAccount();
	}

}
