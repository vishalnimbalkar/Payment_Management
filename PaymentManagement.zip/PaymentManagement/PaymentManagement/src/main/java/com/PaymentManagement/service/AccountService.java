package com.PaymentManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PaymentManagement.dao.AccountDao;
import com.PaymentManagement.dao.UserAccountDao;
import com.PaymentManagement.dao.UserDao;
import com.PaymentManagement.entity.Account;
import com.PaymentManagement.entity.User;
import com.PaymentManagement.entity.UserAccount;

@Service
public class AccountService {

	@Autowired
	AccountDao accountDao;
	
	
	public List<Account> getAccount() {
		return accountDao.getAccount();
	}
	public List<Account> getByAccNo(String accNo) {
		return accountDao.getByAccNo(accNo);
	}
	public List<Account> getUserAccount() {
		return accountDao.getUserAccount();
	}

}
