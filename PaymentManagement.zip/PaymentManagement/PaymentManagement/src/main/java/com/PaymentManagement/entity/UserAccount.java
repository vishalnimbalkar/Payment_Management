package com.PaymentManagement.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="user_account")
public class UserAccount {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int userAccount_id;
	
	@ManyToOne(fetch=FetchType.EAGER)
	private User user;
	
	@OneToOne(fetch=FetchType.EAGER)
	private Account account;
		
	public int getUserAccount_id() {
		return userAccount_id;
	}
	public void setUserAccount_id(int userAccount_id) {
		this.userAccount_id = userAccount_id;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	@Override
	public String toString() {
		return "UserAccount [userAccount_id=" + userAccount_id + ", user=" + user + ", account=" + account + "]";
	}
	
	
	
	
	
	
	
}
