package com.PaymentManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.PaymentManagement.entity.PaymentHistory;
import com.PaymentManagement.entity.UserAccount;

@SpringBootApplication
public class PaymentManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentManagementApplication.class, args);
	}

	@Bean
	public PaymentHistory setPaymentHistory() {
		PaymentHistory ph =new PaymentHistory();
		return ph;
	}
}