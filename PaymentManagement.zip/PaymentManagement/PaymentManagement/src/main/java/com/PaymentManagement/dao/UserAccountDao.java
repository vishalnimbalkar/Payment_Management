package com.PaymentManagement.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.PaymentManagement.entity.User;
import com.PaymentManagement.entity.UserAccount;

@Repository
public class UserAccountDao {

	@Autowired
	SessionFactory sf;
	
	public List<UserAccount> getAllUserAccount() {
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(UserAccount.class);
			List<UserAccount> list=cr.list();
		s.close();
		return list;
	}
	
	public void addUserAccount(UserAccount userAccount) {
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
	      s.save(userAccount);
		tr.commit();
		s.close();		
	}


}
